import React, { useContext } from 'react';
import { BrowserRouter as Router, Routes, Route, Navigate } from 'react-router-dom';
import { AuthContext } from './context/AuthContext';
import ProductForm from './components/ProductForm';
import SalesRegister from './components/SalesRegister';
import ReportDashboard from './components/ReportDashboard';
import Login from './components/Login';
import Navbar from './components/Navbar';
import ErrorBoundary from './components/ErrorBoundary';

const App = () => {
  const { user } = useContext(AuthContext);

  return (
    <Router>
      <ErrorBoundary>
        <div className="min-h-screen bg-gray-100">
          {user && <Navbar />}
          <Routes>
            <Route path="/login" element={user ? <Navigate to="/" /> : <Login />} />
            <Route
              path="/products"
              element={<PrivateRoute component={ProductForm} roles={['admin']} />}
            />
            <Route
              path="/sales"
              element={<PrivateRoute component={SalesRegister} roles={['admin', 'employee']} />}
            />
            <Route
              path="/reports"
              element={<PrivateRoute component={ReportDashboard} roles={['admin']} />}
            />
            <Route
              path="/"
              element={<PrivateRoute component={ProductForm} roles={['admin', 'employee']} />}
            />
          </Routes>
        </div>
      </ErrorBoundary>
    </Router>
  );
};

const PrivateRoute = ({ component: Component, roles }) => {
  const { user } = useContext(AuthContext);
  return user && roles.includes(user.role) ? <Component /> : <Navigate to="/login" />;
};

export default App;