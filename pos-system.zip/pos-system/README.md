A production-ready web-based POS system built with React.js, Node.js/Express.js, PostgreSQL, and Redis, featuring product management, inventory control, sales registration, and reporting.

## Features
- **Product Management**: Add, edit, delete products with name, description, price, and category.
- **Inventory Management**: Track stock per branch, auto-update on sales, low-stock alerts via email.
- **Sales Registration**: Quick sales entry, detailed invoices, print/email options.
- **Reports & Stats**: Sales performance reports with filters, visualized in charts/tables.
- **User Interface**: Responsive, minimalistic design with Tailwind CSS, error boundaries, and pagination.
- **Security**: JWT-based authentication, role-based access, rate limiting, input validation.
- **Notifications**: Email alerts for low stock and transaction errors, processed via Redis.
- **Performance**: API caching, response compression, request logging.
- **Backup**: Automated database backups.
- **CI/CD**: GitHub Actions pipeline for automated testing.
- **API Documentation**: Swagger/OpenAPI documentation at `/api-docs`.

## Prerequisites
- Node.js (v18+)
- PostgreSQL (v14+)
- Redis (v6+)
- Docker (optional, for containerized setup)

## Installation
1. **Clone the repository**:
   ```bash
   git clone <repository-url>
   cd pos-system
   ```

2. **Set up environment variables**:
   - Backend: Copy `backend/.env.example` to `backend/.env` and fill in:
     ```env
     DATABASE_URL=postgresql://user:password@localhost:5432/pos_db
     JWT_SECRET=your_jwt_secret
     REDIS_URL=redis://localhost:6379
     EMAIL_HOST=smtp.example.com
     EMAIL_PORT=587
     EMAIL_USER=your_email
     EMAIL_PASS=your_email_password
     NODE_ENV=development
     ```
   - Frontend: Copy `frontend/.env.example` to `frontend/.env` and fill in:
     ```env
     REACT_APP_API_URL=http://localhost:5000/api
     ```

3. **Install dependencies**:
   ```bash
   cd backend && npm install
   cd ../frontend && npm install
   ```

4. **Set up PostgreSQL and Redis**:
   - Create a database named `pos_db`.
   - Run the schema: `psql -U user -d pos_db -f database/init.sql`
   - Ensure Redis is running: `redis-server`

5. **Run the application**:
   - Backend: `cd backend && npm run dev`
   - Frontend: `cd frontend && npm start`

6. **Optional: Use Docker**:
   ```bash
   docker-compose up --build
   ```

## Usage
- Access the app at `http://localhost:3000`.
- Register a new user or log in with admin credentials (set via environment variables).
- Navigate through the dashboard to manage products, register sales, or view reports.
- View API documentation at `http://localhost:5000/api-docs`.

## Backup
- Run `database/backup.sh` to create a database backup:
  ```bash
  chmod +x database/backup.sh
  ./database/backup.sh
  ```

## Testing
- Backend tests: `cd backend && npm test`
- Frontend tests: `cd frontend && npm test`

## CI/CD
- A GitHub Actions pipeline (`ci.yml`) runs tests on push/pull requests to the `main` branch.
- Configure secrets in GitHub for `TEST_ADMIN_EMAIL` and `TEST_ADMIN_PASSWORD`.

## Project Structure
- `backend/`: Node.js/Express.js API with routes, middleware, services, and Swagger docs.
- `frontend/`: React.js app with components, context, tests, and error boundaries.
- `database/`: PostgreSQL schema and backup script.
- `.github/`: GitHub Actions workflow for CI/CD.

## Extending the System
- Add more branches by updating the `branches` table.
- Enhance reports with additional metrics or visualizations.
- Integrate performance monitoring (e.g., New Relic, Datadog).
- Implement user-based rate limiting for enhanced security.

## Notes
- Ensure PostgreSQL and Redis are running before starting the backend.
- Use environment variables for all sensitive data.
- Regularly back up the database to prevent data loss.
- For production, configure a proper SMTP service for email notifications.
```

### Backend: index.js (Updated)
```javascript
require('dotenv').config();
const express = require('express');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('./middleware/rateLimit');
const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const inventoryRoutes = require('./routes/inventory');
const salesRoutes = require('./routes/sales');
const reportRoutes = require('./routes/reports');
const swaggerRoutes = require('./routes/swagger');
const { errorHandler } = require('./middleware/error');

const app = express();

app.use(cors());
app.use(compression());
app.use(morgan('combined')); // Request logging
app.use(express.json());
app.use(rateLimit);

app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/sales', salesRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api-docs', swaggerRoutes);

app.use(errorHandler);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
```

### Backend: routes/swagger.js (New)
```javascript
const express = require('express');
const router = express.Router();
const swaggerUi = require('swagger-ui-express');
const swaggerDocument = require('../swagger.yaml');

router.use('/', swaggerUi.serve, swaggerUi.setup(swaggerDocument));

module.exports = router;
```

### Backend: swagger.yaml (New)
```yaml
openapi: 3.0.3
info:
  title: POS System API
  version: 1.0.0
  description: API for a Point of Sale system
paths:
  /api/products:
    get:
      summary: Get all products
      responses:
        '200':
          description: List of products
          content:
            application/json:
              schema:
                type: array
                items:
                  $ref: '#/components/schemas/Product'
        '500':
          description: Server error
      security:
        - bearerAuth: []
    post:
      summary: Create a new product
      requestBody:
        required: true
        content:
          application/json:
            schema:
              $ref: '#/components/schemas/ProductInput'
      responses:
        '201':
          description: Product created
          content:
            application/json:
              schema:
                $ref: '#/components/schemas/Product'
        '400':
          description: Invalid input
        '500':
          description: Server error
      security:
        - bearerAuth: []
components:
  schemas:
    Product:
      type: object
      properties:
        id:
          type: integer
        name:
          type: string
        description:
          type: string
        price:
          type: number
        category:
          type: string
      required:
        - name
        - price
        - category
    ProductInput:
      type: object
      properties:
        name:
          type: string
        description:
          type: string
        price:
          type: number
        category:
          type: string
      required:
        - name
        - price
        - category
  securitySchemes:
    bearerAuth:
      type: http
      scheme: bearer
      bearerFormat: JWT