const express = require('express');
const router = express.Router();
const pool = require('../config/db');
const redis = require('../config/redis');
const authMiddleware = require('../middleware/auth');
const { validateProduct } = require('../middleware/validate');
const { sendLowStockNotification } = require('../services/notification');

// Get all products (with caching)
router.get('/', authMiddleware(['admin', 'employee']), async (req, res) => {
  const cacheKey = 'products_all';
  try {
    // Check Redis cache
    const cached = await redis.get(cacheKey);
    if (cached) {
      return res.json(JSON.parse(cached));
    }

    // Fetch from DB
    const result = await pool.query('SELECT * FROM products');
    const products = result.rows;

    // Store in Redis (expire in 5 minutes)
    await redis.setEx(cacheKey, 300, JSON.stringify(products));
    res.json(products);
  } catch (err) {
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// Add a product
router.post('/', authMiddleware(['admin']), validateProduct, async (req, res) => {
  const { name, description, price, category } = req.body;
  try {
    const result = await pool.query(
      'INSERT INTO products (name, description, price, category) VALUES ($1, $2, $3, $4) RETURNING *',
      [name, description, price, category]
    );
    // Invalidate cache
    await redis.del('products_all');
    res.status(201).json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// Update a product
router.put('/:id', authMiddleware(['admin']), validateProduct, async (req, res) => {
  const { id } = req.params;
  const { name, description, price, category } = req.body;
  try {
    const result = await pool.query(
      'UPDATE products SET name = $1, description = $2, price = $3, category = $4 WHERE id = $5 RETURNING *',
      [name, description, price, category, id]
    );
    if (result.rows.length === 0) return res.status(404).json({ error: 'Product not found' });
    // Invalidate cache
    await redis.del('products_all');
    res.json(result.rows[0]);
  } catch (err) {
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

// Delete a product
router.delete('/:id', authMiddleware(['admin']), async (req, res) => {
  const { id } = req.params;
  try {
    const result = await pool.query('DELETE FROM products WHERE id = $1 RETURNING *', [id]);
    if (result.rows.length === 0) return res.status(404).json({ error: 'Product not found' });
    // Invalidate cache
    await redis.del('products_all');
    res.json({ message: 'Product deleted' });
  } catch (err) {
    res.status(500).json({ error: 'Database error', details: err.message });
  }
});

module.exports = router;