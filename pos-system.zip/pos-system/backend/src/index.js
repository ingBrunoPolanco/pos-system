require('dotenv').config();
const express = require('express');
const cors = require('cors');
const compression = require('compression');
const morgan = require('morgan');
const rateLimit = require('./middleware/rateLimit');
const authRoutes = require('./routes/auth');
const productRoutes = require('./routes/products');
const inventoryRoutes = require('./routes/inventory');
const salesRoutes = require('./routes/sales');
const reportRoutes = require('./routes/reports');
const swaggerRoutes = require('./routes/swagger');
const { errorHandler } = require('./middleware/error');

const app = express();

app.use(cors());
app.use(compression());
app.use(morgan('combined')); // Request logging
app.use(express.json());
app.use(rateLimit);

app.use('/api/auth', authRoutes);
app.use('/api/products', productRoutes);
app.use('/api/inventory', inventoryRoutes);
app.use('/api/sales', salesRoutes);
app.use('/api/reports', reportRoutes);
app.use('/api-docs', swaggerRoutes);

app.use(errorHandler);

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));